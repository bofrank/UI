<?php
$servername='mysql-instance-1.c9fyolcrwtal.us-west-2.rds.amazonaws.com:3306';
$adminname='kimchislap';
$password='h0tt0p1c5!';
?> 
